/* Dead Reckoning — tunnel-figure
   Seeded contour terrain (marching squares over a smooth scalar field) with a
   route that follows the valley, then tunnels straight through the ridge. The
   seed makes the terrain deterministic; the route is the signature. */
(function () {
  'use strict';

  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // smooth field: a few seeded gaussian hills/basins + one dominant ridge
  function makeField(seed) {
    var r = mulberry32(seed >>> 0);
    var bumps = [];
    for (var i = 0; i < 4; i++) {
      bumps.push({ cx: 0.12 + r() * 0.76, cy: 0.12 + r() * 0.76,
                   h: (r() * 2 - 1) * 1.1, s: 0.13 + r() * 0.16 });
    }
    var k = 1.1 + r() * 1.1, ph = r() * 6.283, ang = (r() * 0.6 - 0.3);
    return function (x, y) {
      var v = 0.55 * Math.sin((x * Math.cos(ang) + y * (0.35 + Math.sin(ang))) * Math.PI * k + ph);
      for (var i = 0; i < bumps.length; i++) {
        var b = bumps[i], dx = x - b.cx, dy = y - b.cy;
        v += b.h * Math.exp(-(dx * dx + dy * dy) / (2 * b.s * b.s));
      }
      return v;
    };
  }

  function interp(level, va, vb, a, b) { var t = (level - va) / (vb - va); return a + t * (b - a); }

  // marching squares -> array of [[x0,y0],[x1,y1]] segments in unit coords
  function isolines(field, cols, rows, level) {
    var segs = [];
    for (var j = 0; j < rows; j++) {
      for (var i = 0; i < cols; i++) {
        var x0 = i / cols, x1 = (i + 1) / cols, y0 = j / rows, y1 = (j + 1) / rows;
        var a = field(x0, y0), b = field(x1, y0), c = field(x1, y1), d = field(x0, y1);
        var idx = (a > level ? 8 : 0) | (b > level ? 4 : 0) | (c > level ? 2 : 0) | (d > level ? 1 : 0);
        if (idx === 0 || idx === 15) continue;
        var top = [interp(level, a, b, x0, x1), y0];
        var right = [x1, interp(level, b, c, y0, y1)];
        var bottom = [interp(level, d, c, x0, x1), y1];
        var left = [x0, interp(level, a, d, y0, y1)];
        var P = {
          1: [left, bottom], 2: [bottom, right], 3: [left, right], 4: [top, right],
          5: [top, left, bottom, right], 6: [top, bottom], 7: [top, left],
          8: [top, left], 9: [top, bottom], 10: [top, right, bottom, left],
          11: [top, right], 12: [left, right], 13: [bottom, right], 14: [left, bottom]
        }[idx];
        if (P.length === 2) segs.push([P[0], P[1]]);
        else { segs.push([P[0], P[1]]); segs.push([P[2], P[3]]); }
      }
    }
    return segs;
  }

  // valley-following route with a straight tunnel through the middle
  function makeRoute(field, n) {
    var pts = [];
    for (var i = 0; i <= n; i++) {
      var x = i / n, best = 1e9, by = 0.5;
      for (var s = 0; s <= 24; s++) {
        var y = 0.22 + (s / 24) * 0.56, f = field(x, y);
        if (f < best) { best = f; by = y; }
      }
      pts.push([x, by]);
    }
    // smooth
    for (var k = 0; k < 3; k++)
      for (var i2 = 1; i2 < pts.length - 1; i2++)
        pts[i2][1] = (pts[i2 - 1][1] + pts[i2][1] + pts[i2 + 1][1]) / 3;
    // tunnel: straight chord across the central span
    var t0 = Math.floor(pts.length * 0.40), t1 = Math.floor(pts.length * 0.60);
    var y0 = pts[t0][1], y1 = pts[t1][1];
    for (var i3 = t0; i3 <= t1; i3++)
      pts[i3][1] = y0 + (y1 - y0) * ((i3 - t0) / (t1 - t0));
    return { pts: pts, t0: t0, t1: t1 };
  }

  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  function draw(canvas, opts) {
    opts = opts || {};
    var seed = parseInt(opts.seed != null ? opts.seed : canvas.dataset.seed || '7', 10);
    var field = makeField(seed);
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var W = canvas.clientWidth, H = canvas.clientHeight;
    canvas.width = W * dpr; canvas.height = H * dpr;
    var ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    var contourCol = cssVar('--contour') || 'rgba(143,162,184,.10)';
    var contourBold = cssVar('--contour-bold') || 'rgba(143,162,184,.18)';
    var routeCol = cssVar('--route-you') || '#e0954a';

    // contours -> offscreen
    var cols = Math.max(24, Math.round(W / 13)), rows = Math.max(14, Math.round(H / 13));
    var levels = [];
    for (var L = -1.3; L <= 1.3; L += 0.26) levels.push(+L.toFixed(2));
    var off = document.createElement('canvas');
    off.width = canvas.width; off.height = canvas.height;
    var oc = off.getContext('2d'); oc.setTransform(dpr, 0, 0, dpr, 0, 0);
    levels.forEach(function (lv, li) {
      var segs = isolines(field, cols, rows, lv);
      oc.lineWidth = (li % 3 === 0) ? 1.1 : 0.7;
      oc.strokeStyle = (li % 3 === 0) ? contourBold : contourCol;
      oc.beginPath();
      segs.forEach(function (s) { oc.moveTo(s[0][0] * W, s[0][1] * H); oc.lineTo(s[1][0] * W, s[1][1] * H); });
      oc.stroke();
    });

    var route = makeRoute(field, 120);

    function render(progress) {
      ctx.clearRect(0, 0, W, H);
      ctx.drawImage(off, 0, 0, W, H);
      var cut = Math.floor(route.pts.length * progress);
      // soft underglow
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = routeCol; ctx.globalAlpha = 0.18; ctx.lineWidth = 6;
      ctx.beginPath();
      for (var i = 0; i <= cut; i++) { var p = route.pts[i]; i ? ctx.lineTo(p[0] * W, p[1] * H) : ctx.moveTo(p[0] * W, p[1] * H); }
      ctx.stroke();
      // route line
      ctx.globalAlpha = 1; ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (var i2 = 0; i2 <= cut; i2++) { var q = route.pts[i2]; i2 ? ctx.lineTo(q[0] * W, q[1] * H) : ctx.moveTo(q[0] * W, q[1] * H); }
      ctx.stroke();
      // tunnel portals (perpendicular ticks) once revealed
      [route.t0, route.t1].forEach(function (ti) {
        if (cut < ti) return;
        var p = route.pts[ti], pa = route.pts[Math.max(0, ti - 1)], pb = route.pts[Math.min(route.pts.length - 1, ti + 1)];
        var ang = Math.atan2((pb[1] - pa[1]) * H, (pb[0] - pa[0]) * W) + Math.PI / 2, r = 7;
        ctx.beginPath();
        ctx.moveTo(p[0] * W + Math.cos(ang) * r, p[1] * H + Math.sin(ang) * r);
        ctx.lineTo(p[0] * W - Math.cos(ang) * r, p[1] * H - Math.sin(ang) * r);
        ctx.stroke();
      });
      // leading marker
      if (cut > 0 && cut < route.pts.length) {
        var head = route.pts[cut];
        ctx.fillStyle = routeCol;
        ctx.beginPath(); ctx.arc(head[0] * W, head[1] * H, 2.6, 0, 6.283); ctx.fill();
      }
    }

    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) { render(1); return { redraw: function () { draw(canvas, opts); } }; }
    var start = null, dur = 1400;
    function step(ts) {
      if (start === null) start = ts;
      var t = Math.min(1, (ts - start) / dur);
      render(t * t * (3 - 2 * t)); // smoothstep
      if (t < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
    return { redraw: function () { draw(canvas, opts); } };
  }

  window.Tunnel = { draw: draw };

  function init() {
    var els = document.querySelectorAll('[data-tunnel]');
    els.forEach(function (el) {
      var inst = draw(el);
      var rt;
      window.addEventListener('resize', function () {
        clearTimeout(rt); rt = setTimeout(function () { inst.redraw(); }, 180);
      });
    });
  }
  if (document.readyState !== 'loading') init();
  else document.addEventListener('DOMContentLoaded', init);
})();
